# DialogueQuestTester Project Future

# Planned Features

## Near version (v0.6.0)

- DialogueQuest v0.6.0

## Future Version

- Flags management GUI (clear flags, add, modify, etc.)
- Deserialization of DQ characters

# Potential features



