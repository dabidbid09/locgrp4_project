# Scene-Changer-Godot-4.x
SceneChanger for Godot 4.x with fade animation 

```gdscript
ChangeScene.load_scane_to_file("path")
ChangeScene.load_scane_to_packed(packed_scene)
```
